/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    08/11/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.pattern;

import heronarts.lx.HeronLX;
import heronarts.lx.LXUtils;
import heronarts.lx.modulator.LinearEnvelope;


public class TouchTestPattern extends LXPattern {
	private final LinearEnvelope brightness;
	
	public TouchTestPattern(HeronLX lx) {
		super(lx);
		this.addModulator(this.brightness = new LinearEnvelope(0, 0, 100));
	}
	
	public void run(int deltaMs) {
		double touchX = (this.lx.width-1) * this.lx.touch().getX();
		double touchY = (this.lx.height-1) * this.lx.touch().getY();
		
		if (this.lx.touch().isActive()) {
			this.brightness.setEndVal(100).trigger();
		} else {
			this.brightness.setEndVal(20).trigger();
		}
		
		for (int i = 0; i < this.lx.total; ++i) {
			double distance = LXUtils.distance(this.lx.column(i), this.lx.row(i), touchX, touchY);
			this.colors[i] = this.lx.colord(
					this.lx.getBaseHue(),
					100,
					Math.max(this.brightness.getValue() - distance*40., 0)			
					);
		}
	}
}
