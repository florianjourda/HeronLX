/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 *
 * @author      Mark Slee http://heronarts.com
 * @modified    08/01/2013
 * @version     0.1.1 (1)
 */

package heronarts.lx.dmx;


import heronarts.lx.RGBNode;

/**
 * Mapping of a RGB pixel to its 3 channels (R, G and B) on the DMXOutput
 */
public class DMXRGBNode extends RGBNode {
	final public int rChannelId;
	final public int gChannelId;
	final public int bChannelId;

	public DMXRGBNode(int nodeIndex, int rChannelId, int gChannelId, int bChannelId) {
		super(nodeIndex);
		this.rChannelId = rChannelId;
		this.gChannelId = gChannelId;
		this.bChannelId = bChannelId;
	}
}

