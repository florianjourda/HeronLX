/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 *
 * @author      Mark Slee http://heronarts.com
 * @modified    08/17/2014
 * @version     0.1.1 (1)
 */

package heronarts.lx.modulator;

import heronarts.lx.LXUtils;

import java.lang.Math;


/**
 * A sawtooth LFO oscillates from one extreme value to another. When the later
 * value is hit, the oscillator rests to its initial value.
 */
public class SawLFO extends LXModulator {
	private double startVal;
	private double endVal;
	private double deltaValuePerDeltaMs;

	public SawLFO(double startVal, double endVal, double durationMs) {
		this.value = this.startVal = startVal;
		this.endVal = endVal;
		this.setDuration(durationMs);
	}

	public SawLFO setRange(double startVal, double endVal, double durationMs) {
		this.startVal = startVal;
		this.endVal = endVal;
		this.value = LXUtils.constrain(this.value, Math.min(startVal, endVal), Math.max(startVal, endVal));
		return this.setDuration(durationMs);
	}

	public SawLFO setDuration(double durationMs) {
		this.deltaValuePerDeltaMs = (this.endVal - this.startVal) / durationMs;
		return this;
	}

	public LXModulator trigger() {
		this.value = this.startVal;
		return this.start();
	}

	protected void computeRun(int deltaMs) {
		this.value += this.deltaValuePerDeltaMs * deltaMs;
		if ((this.deltaValuePerDeltaMs > 0) && (this.value > this.endVal)) {
			this.value = this.startVal + (this.value - this.endVal);
		} else if ((this.deltaValuePerDeltaMs < 0) && (this.value < this.endVal)) {
			this.value = this.startVal - (this.endVal - this.value);
		}
	}
}