/**
 * HeronLX
 * A collection of utilities for solving this and that problem.
 * http://heronarts.com/#lx
 *
 * Copyright (C) 2012 Mark Slee http://heronarts.com
 * All Rights Reserved
 * 
 * @author      Mark Slee http://heronarts.com
 * @modified    08/16/2014
 * @version     0.1.1 (1)
 */

package heronarts.lx.control;

public abstract class LXParameter {

	public interface Listener {
		public void onParameterChanged(LXParameter parameter);
	}

	public abstract void setValue(double value);
	public abstract double getValue();
	
	public float getValuef() {
		return (float) getValue();
	}
	
	public abstract String getLabel();
}
