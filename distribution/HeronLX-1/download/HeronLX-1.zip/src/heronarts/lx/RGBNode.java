package heronarts.lx;

abstract public class RGBNode {
	final public int nodeIndex;

	public RGBNode(int nodeIndex) {
		this.nodeIndex = nodeIndex;
	}
}
